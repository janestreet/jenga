#ifndef CORE_CONFIG_H
#define CORE_CONFIG_H
#define JSC_ARCH_SIXTYFOUR
#define JSC_ARCH_amd64
#define JSC_OCAML_4_01
#endif /* CORE_CONFIG_H */
