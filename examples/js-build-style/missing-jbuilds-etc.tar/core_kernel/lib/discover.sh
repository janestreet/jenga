#!/bin/bash

set -e

if [ $# -lt 2 ]; then
    echo "Usage: discover.sh OCAMLC ML_OUTFILE C_OUTFILE" >&2
    exit 2
fi

OCAMLC="$1"
ML_OUTFILE="$2"
C_OUTFILE="$3"
shift 3

MAKEFILE_CONFIG=`$OCAMLC -where`/Makefile.config
if [ ! -e $MAKEFILE_CONFIG ]; then
    echo "Makefile.config missing in ocaml standard library path."
    echo 2
fi

ARCH=`cat $MAKEFILE_CONFIG | grep '^ARCH=' | cut -d= -f2`

SRC=test.c
OUT=test.out
trap "rm -f $OUT" EXIT

$OCAMLC -ccopt -E -c $SRC | grep '^"OUT:[^"]*"$' | sed 's/"OUT:\([^"]*\)"/\1/' | tee > $OUT

echo "DEFINE ARCH_$ARCH" >> $OUT


# ocaml version
if [[ ! "$($OCAMLC -version)" < "4.01" ]]; then
  echo "DEFINE OCAML_4_01" >> "$OUT"
fi

mv "$OUT" "$ML_OUTFILE"

{
    sentinel="CORE_`basename "$C_OUTFILE" | tr a-z. A-Z_`"
    cat  <<EOF
#ifndef $sentinel
#define $sentinel
EOF
    sed 's/^DEFINE */#define JSC_/' "$ML_OUTFILE"
    cat  <<EOF
#endif /* $sentinel */
EOF
} > "$C_OUTFILE"
